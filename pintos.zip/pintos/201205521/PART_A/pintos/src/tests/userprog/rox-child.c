/* Ensure that the executable of a running process cannot be
   modified, even by a child process. */

#define CHILD_CNT "1"
#include "tests/userprog/rox-child.inc"
