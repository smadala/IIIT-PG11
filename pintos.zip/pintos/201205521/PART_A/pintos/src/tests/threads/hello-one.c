#include <stdio.h>
void test_hello_one(int x)
{
	if(x == 2575)
		printf("I, Loki, THE most powerful GOD destroys the peaceful land of Pintos *Evil-laugh* !!!!\n");
	if(x == 666)
		printf("Spiderman in Asgard??! Heaven's sake, I need to abort this mission and fly off to my home.. :(\n");
}
