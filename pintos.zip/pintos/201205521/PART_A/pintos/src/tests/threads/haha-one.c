#include <stdio.h>
void test_haha_one(void)
{
	test_hello_one(666);
}
