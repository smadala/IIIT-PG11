For producer consumer code, perform mutex lock on corresponding variable before reading / writing on the variable and mutex unlock after read/write is complete.
After the value of a variable is generated, signal on corresponding condition. Also set corresponding flag. If flag indicating that data is generated is not set, then wait till flag is set. Once value of variable is read, reset the flag.
