#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

void* banking(void *);
int account1 = 0, account2 = 0;

int main()
{
	int counter = 0;
	pthread_t tid1, tid2;

	if(pthread_create(&tid1, NULL, &banking, &counter))
	{
		perror("pthread_create");
		return 1;
	}

	if(pthread_create(&tid2, NULL, &banking, &counter))
	{
		perror("pthread_create");
		return 1;
	}
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	return 0;
}

void* banking(void *data)
{
	int counter = 0, temp1, temp2, amount;
	do
	{
		temp1 = account1;
		temp2 = account2;
		amount = rand();
		account1 = temp1 - amount;
		account2 = temp2 + amount;
		counter++;
	}while (account1 + account2 == 0);

	printf("%d\n", counter);
	return NULL;
}
