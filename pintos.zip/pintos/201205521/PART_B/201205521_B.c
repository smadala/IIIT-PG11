#include <stdlib.h>		//rand()
#include <pthread.h>	//pthread_*()
#include <unistd.h>		//sleep()
#include <stdio.h>		//I/O

pthread_mutex_t mutex_x, mutex_y;
int var_x = 0, var_y = 0;
pthread_cond_t cond_y, cond_x;
int flag_y = 0, flag_x = 0;

void *procA(void* ptr) {
	while (1) {
		pthread_mutex_lock(&mutex_x);
		var_x = rand();
		flag_x = 1;
		printf("Generated X=%d\n", var_x);
		pthread_mutex_unlock(&mutex_x);
		pthread_cond_signal(&cond_x);
		pthread_mutex_lock(&mutex_y);
		if (flag_y == 0) {
			pthread_cond_wait(&cond_y, &mutex_y);
		}
		printf("Read Y=%d\n", var_y);
		flag_y = 0;
		pthread_mutex_unlock(&mutex_y);
//		sleep(rand()%4);
	}
	return NULL;
}

void *procB(void* ptr) {
	while (1) {
		pthread_mutex_lock(&mutex_x);
		if (flag_x==0) {
			pthread_cond_wait(&cond_x, &mutex_x);
		}
		printf("Read X=%d\n", var_x);
		flag_x = 0;
		pthread_mutex_unlock(&mutex_x);
		pthread_mutex_lock(&mutex_y);
		var_y = rand();
		flag_y = 1;
		printf("Generated Y=%d\n", var_y);
		pthread_mutex_unlock(&mutex_y);
		pthread_cond_signal(&cond_y);
//		sleep(rand()%3);
	}
	return NULL;
}

int main()
{
     pthread_t t1, t2;
     int procAarg ,procBarg;
     int  r1, r2;
     pthread_cond_init (&cond_y, NULL);
     pthread_cond_init (&cond_x, NULL);
     pthread_mutex_init(&mutex_x, NULL);
     pthread_mutex_init(&mutex_y, NULL);
     r1 = pthread_create( &t1, NULL, &procA, &procAarg);
     r2 = pthread_create( &t2, NULL, &procB, &procBarg);
     pthread_join( t1, NULL);
     pthread_join( t2, NULL);
     pthread_mutex_destroy(&mutex_x);
     pthread_mutex_destroy(&mutex_y);
     pthread_cond_destroy(&cond_y);
     pthread_cond_destroy(&cond_x);
     return 0;
}
