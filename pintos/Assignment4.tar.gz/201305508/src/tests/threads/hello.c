#include <stdio.h>

void test_hello(void)
{
	printf("Hello World!!\n");
}
