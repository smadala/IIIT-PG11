﻿Scripting and Computer Environments (CSE 505)

Getting started with Shell Scripting

Now that you have learnt how to use basic commands and filters, its time to put all of these together to create scripts that are more powerful than using these commmands alone. 

How to use these resources:

It is better to follow this sequence:

1)Start with the scripts in 'Introductory-Scripts.tar.gz' along with its usage doc 'ShellScriptingIntro.pdf'
2)Follow the attached slides
3)Study the scripts in 'Example-scripts.tar.gz'

 If you have any queries, please drop a mail to the mailing list.
