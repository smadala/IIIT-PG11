#!/bin/bash

# Demo of integer and string comparisons in bash
# the 'test' statement tests a condition 
# This script checks the EXIT STATUS of previous invocation of 'test'
# Note that 0 means successful (true) and 1 means otherwise. 

x=4
y=6


test $x -eq $y ; echo "x=y is : $?"           # Equal?

test $x -ne $y ; echo "X!=y is : $?"          # Not equal?

test $x -gt $y ; echo "x>y is : $?"            # Greater ?

test $x -ge $y ; echo "x>=y is : $?"           # Greater or equal?

test $x -lt $y ; echo "x<y is : $?"            # Lesser?
 
test $x -le $y ; echo "x<= is : $?"            # Less or equal?

echo "=======STRING COMPARISON================"

str1="hello"
str2="Hello"

test $str1==$str2 ; echo "str1=str2 is : $?"          # Equal?

test $str1!=$str2 ; echo "str1!=str2 is : $?"       # Not Equal?

test -z $str1; echo "Is str1 null? $? "                # Null string? 

test -n $str2 ; echo "Is str2 non-zero?  $?"           # Not null? 

