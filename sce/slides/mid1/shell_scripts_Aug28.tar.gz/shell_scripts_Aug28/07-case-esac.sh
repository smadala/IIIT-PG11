#!/bin/bash 

# A script to demo the case construct

echo -e "        MENU
1. See who is logged in 
2. See list of files 
3. See the Calendar 
4. See user processes 
[QqEeXx]. Quit \n"

echo -n "Enter your choice [0-5]  :  "

read choice		        # read the user's input 

case $choice in 

	1) who ;;

	2) ls -l ;; 

	3) cal  ;;

	4) ps -f ;;

       [Qq] | [Ee] | [Xx] ) echo "Bye bye" ; exit ;;    # regex possible 

	*) echo "Invalid input!" ;;           # If any other  

esac 

exit 0 


