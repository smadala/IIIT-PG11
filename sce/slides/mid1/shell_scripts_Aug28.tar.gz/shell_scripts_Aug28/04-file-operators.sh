#!/bin/bash

# File operators in action 
# Again, exit stats=0  means True and any other value means False

file=$0

test -e $file ; echo "Does $0 exist?  $?"

test -s $file; echo "Is $0 non-empty?  $?"

test -r $file; echo "Is $0 Readable?  $?"

test -w $file; echo "Is $0 Writable?  $?"

test -x $file; echo "Is $0 Executable?  $?"

test -L $file; echo "Is $0 a symbolic link?  $?"

test -f $file; echo "Is $0 a regular file?  $?"

test -d $file; echo "Is $0 a directory?  $?"

test $file -nt $0; echo "Is $file newer than $0?  $?"

exit 0

