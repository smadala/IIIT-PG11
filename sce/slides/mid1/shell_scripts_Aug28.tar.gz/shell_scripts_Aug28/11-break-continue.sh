#!/bin/bash 

# demo of the break and continue statements 


# the break statment breaks out of the loop 
echo "========= BREAK =============="
for i in `seq 1 5 50`

do
    if [ $(($i%2)) -eq 0 ]
    then
	    break
    fi

    echo $i

done

echo "============ CONTINUE=========="

# the 'continue statment suspends current iteration and skips to the next 

for i in {1..50} 				#or for i in `seq 1 50`
do 
    if [ $(($i%2)) -eq 0 ]
   then
           continue
   fi 

   echo $i

done 


