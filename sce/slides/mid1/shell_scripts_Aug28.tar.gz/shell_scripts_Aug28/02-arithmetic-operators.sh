#!/bin/bash

# Doing integer arithmetic using the 'let'  and the ((...)) constructs
# 'let' is a less complex version of 'expr' 
# ((...)) allows C-style manipulation of variables

let X=5                       

let X-=2

let X++

echo "X: $X"

let Y=X*10

let Y--

echo "Y: $Y"


echo "================================"

(( a=5 ))

(( a++ ))

echo "a: $a"

echo $((20+30))                     # expr 20 + 30

echo $(($X + 4))                    # expr $x + 4 

echo "==============================="


exit 0
