#!/bin/bash

#Demo of a simple if statment
# if [ expression ]
# then
# do something 
# fi

# The test command serves its purpose well here
if test -f $0
then
      echo "$0 is an ordinary file"
fi

# we can semicolon-delimit the 'if' and 'then' statements on same line
if test -s $0 ; then
   echo "$0 is non-empty"
fi

# The [] construct also can be used. Mind the space after '[' and before ']'.

if [ -f $0 ] ; then  
   echo "$0 is an ordinary file"
fi

# You can also use the [[ ]] construct to test a condition. 
# Unlike [], the latter allows you to use && and || inside. 


exit 0
