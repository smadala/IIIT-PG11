#!/bin/bash
# A simple script to demo the 'if' construct. 
# It accepts a user name from the command line. 

if who | grep $1 > /dev/null 

then 

echo "$1 is logged in."

else

echo "$1 is not logged in" 

echo

fi 

exit 0 


