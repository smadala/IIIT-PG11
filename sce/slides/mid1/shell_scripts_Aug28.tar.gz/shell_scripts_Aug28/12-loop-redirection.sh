#!/bin/bash

# Input from a file can be redirected to loops
# Output from loops as well can be redirected to a file

# 1. Input redirection 
# simply, put the redirection at the end of the loop statment 
#    while/until ...
#    do
#    ...
#    done  < filename  


while read line
do
	print $line
done < file.txt 



# 2. Output redirection 
# Put the redirection at the end of the loop 

for i in `cat $1`
do
	print $i

done  > output.txt 



# 3. Loop Piping      (See the usages given below. Try out your own examples)

# Input piping - we can pipe input to a loop.

#    command | while  read                     # possible for until too
#    do 
#    ...
#    done


# Output piping - we can also pipe output from a loop 

#  while ...                   # for ...
#  do                          # do 
#	....                   # ...
#  done  | command             # done | command


