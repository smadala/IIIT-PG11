#!/bin/sh

# this scripts takes two numbers from command line 
# and does the basic arithmetic operations on 'em.
# N.B. There should be spaces b/n operators and operands

x=$1
y=$2

sum=`expr $x + $y`            #notice the back tick
echo "Sum : $sum"

diff=`expr $x - $y`
echo "Difference : $diff"

prod=`expr $x \* $y`          # notice the escape character
echo "Product : $prod"

quot=`expr $x / $y`
echo "Quotient : $quot"

rem=`expr $x % $y`
echo "Remainder : $rem"

exit 0


