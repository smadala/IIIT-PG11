#!/bin/bash
X=5
echo "A quote is \", backslash is \\, backtick is \`."
echo "A few spaces are    ; dollar is \$. \$X is ${X}."

echo "Use of \$ : $USER"
echo "Use of \` : 4+3=`echo 4+3|bc`"
echo "Use of \\ : This is a double quote \""

#More examples in 07-quotes.sh of Example Scripts"
