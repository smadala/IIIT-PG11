#!/bin/bash

# This is simple hello world script.
# We can write comments on lines 
# starting with hash (#) character

echo Hello World!
exit 0

# It is good habit to return 0 if 
# script ends successfully.

