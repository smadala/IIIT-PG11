#!/bin/grep "hello"

Hi!
This file will be interpreted by grep
to search for the pattern "hello"


