#!/bin/grep ^[^#]

#When you see the output, commented and empty lines wont get
#printed as grep wont grep them :)

You may read 05-grep.sh to understand the output.
Actual file is bigger than what is being displayed
 
#Above line has intentional space character

#You must understand the regular expression
#Do not enclose above expression in single quotes ('')
#Single quotes were used to protect arguments from shell
#We wont be passing arguments to shell here
#So escaping things that shell interferes with is not required


