#!/bin/bash

#Environment variables are automatically avaiable
echo 'HOME folder is' $HOME

A=BCD
echo 'A is' $A

echo 'B is' $B
echo 'a is' $a

exit 0


