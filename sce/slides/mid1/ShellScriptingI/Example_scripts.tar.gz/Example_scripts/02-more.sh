#!/bin/more

You can see this file screenful at a time.




1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1








1







1





