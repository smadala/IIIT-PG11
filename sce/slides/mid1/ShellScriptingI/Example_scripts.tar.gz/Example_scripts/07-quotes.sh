#!/bin/bash

A='a b c'

echo '1. A is' $A
echo "2. A is" $A
echo '3. $A is' $A
echo "4. $A is" $A
echo "5. \$A is" $A
echo '6. $A is $A'
echo "7. $A is $A"
echo "8. \$A is $A"

exit 0
