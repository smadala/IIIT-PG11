#!/bin/bash

#This is a comment

	#This is also comment

ls	#ls command wont get affected by this comment

echo 'Three hashes would follow:'
echo \#		#Would print # on output stream. Note the spaces that precede hash
		#character in each comment
echo "#"
echo '#'

#Try command 'ls #comment' on command line when you read this

exit 0

