#!/usr/bin/python

str=raw_input("Hello! What is your name?")

