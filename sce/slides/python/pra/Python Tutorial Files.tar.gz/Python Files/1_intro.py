#!/usr/bin/python

print "Python is really a great language,", "isn't it?";

str = raw_input("Enter your input: ");
#Try this as input ! : [x*10 for x in range(1,10)]
print "Received input is : ", str

str = input("Enter your input: ");
#Try this as input ! : [x*10 for x in range(1,10)]
print "Received input is : ", str

#raw_input() is therefore used to input strings and input() is normally used to input numbers


