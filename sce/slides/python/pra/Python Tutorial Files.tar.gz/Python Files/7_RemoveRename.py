#!/usr/bin/python
import os

#rename syntax:
#os.rename(current_file_name, new_file_name)

# Rename a file from test1.txt to test2.txt
os.rename( "test1.txt", "test2.txt" )

#remove syntax:
#os.remove(file_name)

os.remove("text2.txt")
