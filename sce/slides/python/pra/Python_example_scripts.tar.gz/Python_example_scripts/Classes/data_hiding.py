#!/usr/bin/python


from encapsulation import privacy  


x = privacy(1,2)

print x.public

#print x.__private		# ???



