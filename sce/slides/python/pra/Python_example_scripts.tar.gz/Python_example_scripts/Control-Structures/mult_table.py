#!/usr/bin/python 

# 12x12  multiplication table 


for row in range(1,13):
	
	for col in range(1,13): 

		print row*col, '\t' ,  

	print 
