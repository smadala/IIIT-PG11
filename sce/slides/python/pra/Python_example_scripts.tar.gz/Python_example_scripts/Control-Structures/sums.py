#!/usr/bin/python

# Script to add integers in the range of [1,99] 

sum=0 

n=100

for i in range(1,n): 

	 sum+=i 		# sum=sum + i

print sum 
