#!/usr/bin/python



S='I am global' 

def f(): 

       print S 


f()                     # call f()  
