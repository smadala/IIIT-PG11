#!/usr/bin/python 

# What is the output of this code snippet? 


a,b,x,y=1,15,3,4


def func(x, y): 

    global a

    a = 42

    x,y = y,x

    b = 33

    b = 17

    c = 100

    print a,b,x,y



func(17,4)


print a,b,x,y

