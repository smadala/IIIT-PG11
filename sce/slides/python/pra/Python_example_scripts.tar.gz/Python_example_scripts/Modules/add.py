import math_func		# imports the math_func.py module

print dir(math_func)

print math_func.add(2,3)

print math_func.sub(2,3)

print math_func.mul(2,3)

print math_func.div(27,3)
