/* This is a Javascript file linked externally 

the <style> tag  is not needed */

document.write ("Hello Hola Namaste!" + "</br>"); 

alert ("This is Javascript in action"); 


