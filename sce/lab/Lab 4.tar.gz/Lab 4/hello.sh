#! /bin/bash

print1(){
	echo "Hello $1"
}
