#! /bin/sh

#recursive scripts are scripts that call themselves
cd $1
for file in *
do
	if [ -f $file ]; then
		echo $file
	else
		#call this script recursively for $file
	fi
done


