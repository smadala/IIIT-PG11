#!/bin/sh

#As with any programming language that includes subroutines, it is often useful to build up a library of common subroutines that your scripts can use. To avoid duplicating this content, the Bourne shell scripting language provides a mechanism to include one shell script inside another by reference. This process is commonly referred to as sourcing.

echo "This is a script that sources another"
. hello.sh
print1 "Ishaya"

