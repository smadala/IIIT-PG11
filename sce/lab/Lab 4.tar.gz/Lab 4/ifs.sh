#! /bin/sh
echo "IFS is '" $IFS "'"

#Internal Field Separator is used for word splitting after expansion and to split lines into words with the read builtin command
#The shell treats each character of IFS as a delimiter, and splits the results of the other expansions into words on these characters.

OLDIFS=$IFS
IFS=";"
var=`cat ifs_input.txt`
echo $var

IFS=$OLDIFS

