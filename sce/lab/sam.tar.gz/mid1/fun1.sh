#!/bin/bash

function f1{
echo "this is f1";
}
f1

