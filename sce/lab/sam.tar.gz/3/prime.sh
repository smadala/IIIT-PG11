#!/bin/bash

echo "enter number: "

read n

temp=2

while [ temp -le n]

t1=temp




 




