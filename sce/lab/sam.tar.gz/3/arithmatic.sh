#!/bin/bash

echo "enter two numbers: "
read n1
read n2

sum=$(($n1+$n2))

echo $sum
exit 0

